export CLASSPATH=".:./lib/byte-buddy-1.8.5.jar:./lib/byte-buddy-agent-1.8.5.jar:./lib/hamcrest-core-1.3.jar:./lib/junit-4.12.jar:./lib/mockito-core-2.18.3.jar:./lib/objenesis-2.6.jar"
rm -f -r ./src/*.class
rm -r EXE
mkdir EXE
cd EXE
mkdir src
cd ..
cp -R ./src/data EXE/src
cp -R lib EXE
javac -d ./EXE ./src/domini/*.java
javac -d ./EXE ./src/utils/*.java
javac -d ./EXE ./src/persistencia/*.java -Xlint
javac -d ./EXE ./src/domini/Drivers/*.java -Xlint