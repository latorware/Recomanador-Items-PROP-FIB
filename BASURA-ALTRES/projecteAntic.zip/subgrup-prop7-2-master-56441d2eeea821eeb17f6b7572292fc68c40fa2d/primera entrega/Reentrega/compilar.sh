cp -r ./FONTS ./EXE
cd ./EXE
export CLASSPATH=".:./lib/byte-buddy-1.8.5.jar:./lib/byte-buddy-agent-1.8.5.jar:./lib/hamcrest-core-1.3.jar:./lib/junit-4.12.jar:./lib/mockito-core-2.18.3.jar:./lib/objenesis-2.6.jar"
javac -d ./ ./FONTS/domini/*.java
javac -d ./ ./FONTS/utils/*.java
javac -d ./ ./FONTS/persistencia/*.java -Xlint
javac -d ./ ./FONTS/domini/Drivers/*.java -Xlint
rm -r ./FONTS
cd ../
cp -r ./FONTS/data ./EXE
cd ./EXE