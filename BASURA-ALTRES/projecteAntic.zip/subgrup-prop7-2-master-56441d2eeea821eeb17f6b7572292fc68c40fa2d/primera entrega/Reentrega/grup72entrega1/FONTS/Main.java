import domini.*;
import persistencia.DataReader;
import java.util.*;
import utils.Pair;

public class Main {

    public static void main(String[] args) throws Exception
    {
        Map<String, TipusAtribut> tipusAtributs = new HashMap<>(); //TIPUSATRIBUT
        Map<Integer, Item> items = new HashMap<>(); //ITEMS
        Map<Integer, Usuari> usuaris = new HashMap<>();
        Map<Pair<Item, Usuari>, Valoracio> valoracions = new HashMap<>();

        DataReader.carregaDades(tipusAtributs, items, usuaris, valoracions);

    }
}