package controladors;

import domini.*;
import persistencia.DataReader;
import utils.Pair;

import java.util.*;

public class CtrlCarregaDades {

    public static ArrayList<String> getHeader(String direccioArxiu) throws Exception {
        return DataReader.getHeader(direccioArxiu);
    }

    public static void carregaItems(String direccioArxiu, HashMap<String, Pair<String, Boolean>> atributs, String id) throws Exception {
        String[][] items = DataReader.getItems(direccioArxiu);

        HashMap<String, TipusAtribut> tipusAtributs = new HashMap<>();
        for (HashMap.Entry<String, Pair<String,Boolean>> set: atributs.entrySet()) {
            TipusAtribut tipusAtribut = new TipusAtribut(set.getKey());
            if (tipusAtributs.containsKey(set.getKey())) throw new Excepcions("Tipus d'atributs duplicats");
            tipusAtributs.put(set.getKey(), tipusAtribut);
        }

        for (int i = 1; i < items.length; ++i) {
            HashSet<Atribut> atributsItem = new HashSet<>();
            Integer idItem = null;
            for (int j = 0; j < items[0].length; ++j) {
                if (Objects.equals(items[0][j], id)) idItem = Integer.parseInt(items[i][j]);
                else {
                    //POT SER QUE HI HAGI UN ERROR PER QUE HI HA ITEMS AMB ATRIBUTS NULLS; S'HA DE PROVAR
                    String nom_atribut = items[0][j];
                    TipusAtribut tipusAtribut = tipusAtributs.get(nom_atribut);
                    Pair<String,Boolean> pair = atributs.get(nom_atribut);
                    Boolean calculable = pair.second();
                    tipusAtribut.setCalculable(calculable);
                    if (Objects.equals(pair.first(), "Bool")) {
                        AtrBool atribut = new AtrBool(tipusAtribut, Boolean.parseBoolean(items[i][j]));
                        atributsItem.add(atribut);
                    }
                    else if (Objects.equals(pair.first(), "Double")) {
                        AtrDouble atribut = new AtrDouble(tipusAtribut, Double.parseDouble(items[i][j]));
                        atributsItem.add(atribut);
                    }
                    else if (Objects.equals(pair.first(), "Int")) {
                        AtrInt atribut = new AtrInt(tipusAtribut, Integer.parseInt(items[i][j]));
                        atributsItem.add(atribut);
                    }
                    else if (Objects.equals(pair.first(), "String")) {
                        AtrString atribut = new AtrString(tipusAtribut, items[i][j]);
                        atributsItem.add(atribut);
                    }
                }
            }
            HashMap<Integer, Valoracio> valoracions = new HashMap<>();
            Item item = new Item(idItem, valoracions, atributsItem);
            CtrlDomini.setItem(idItem, item);
        }
    }

    public static void carregaValoracions(String direccioArxiu) throws Exception {
        String[][] valoracions = DataReader.getValoracions(direccioArxiu);

        String descripcio = null;
        Integer userId;
        Integer itemId;
        Double rating;

        int numCol = valoracions[0].length;

        for (int i = 1; i < valoracions.length; ++i) {
            userId = Integer.parseInt(valoracions[i][0]);
            itemId = Integer.parseInt(valoracions[i][1]);
            rating = Double.parseDouble(valoracions[i][0]);
            if (numCol > 3) descripcio = valoracions[i][3];
            CtrlDomini.creaUsuariNoActiu(userId);
            CtrlDomini.creaValoracio(userId, itemId, rating, descripcio);
        }


    }

    public static void carregaRecomanacio(String direccioArxiu) {
        String[][] recomanacions = DataReader.get
    }

}