package controladors;

import domini.*;

import java.rmi.server.RemoteServer;
import java.text.AttributeEntry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import utils.Pair;
import utils.randoms;


public class CtrlDomini {

    /**
     * ATRIBUTS DE LA CLASSE
     */


    /**
     * Tots els usuaris existents trobats, ja siguin possibles actius o no actius. Tots, menys l'usuari que té la sessió iniciada, si és que n'hi ha algun. 
     */
    private static HashMap<Integer, Usuari> usuaris = new HashMap<>();

    /**
     * 
     */
    private static HashMap<Integer, Item> items = new HashMap<>();

    /**
     * Usuari actiu, que te la sessió iniciada. Si no n'hi ha cap amb la sessió iniciada, serà nul. 
     */
    private static U_Actiu usuariActiu;


    /**
     * Classe que conté les distàncies entre l'usuari que té la sessió iniciada, i tots els altres
     */
    private Dist_usuari dist_usuariActiu;

    public CtrlDomini() {}

    /**
     * Dades
     */

    // El CtrlPresentacio pregunta els atributs disponibles per posteriorment
    // decidir de quin tipus és cada atribut i dir si és calculable o no.
    public static ArrayList<String> getHeader(String direccioArxiu) throws Exception {
        return CtrlCarregaDades.getHeader(direccioArxiu);
    }

    // El CtrlPresentacio ens indica el tipus i tot de cada atribut. Creem els atributs amb els quals operarem.
    // Ens passen El nom de l'atribut, el seu tipus i si és calculable,
    // Llegim els items i els creem i afegim tot el necessari.
    public static void carregaItems(String direccioArxiu, HashMap<String, Pair<String, Boolean>> atributs, String id) throws Exception {
        CtrlCarregaDades.carregaItems(direccioArxiu, atributs, id);
    }


    public static void carregaValoracions(String direccioArxiu) throws Exception {
        CtrlCarregaDades.carregaValoracions(direccioArxiu);
    }


    public static void carregaRecomanacio(String direccioArxiu){
        CtrlCarregaDades.carregaRecomanacio(direccioArxiu);
    }

    public static void guardaItems(){ CtrlGuardaDades.carregaItems(); }

    public static void guardaValoracions(){ CtrlGuardaDades.carregaValoracions(); }

    public static void guardaRecomanacio(){ CtrlGuardaDades.guardaRecomanacio(); }


    /**
     * Recomanacions
     */

    public static void creaRecomanacio(){ CtrlRecomanacio.creaRecomanacio(); }

    public static void valoraRecomanacio(){ CtrlRecomanacio.valoraRecomanacio(); }

    /**
     * Items
     */

    public static boolean creaItem(HashSet<Atribut> atributs) throws Excepcions.UnexistingAtributsException {
        HashMap<Integer, Valoracio> valoracions  = new HashMap<>();
        Boolean assignat = false;
        int i;
        for (i = 0; (i < usuaris.size() + 2) && (assignat = false); ++i) {
            if (!usuaris.containsKey(i)) assignat = true;
        }
        Item item = new Item(i , valoracions, atributs);
        items.put(item.getID(), item);
        return true;
    }

    public static boolean editaItem(int idItem, ArrayList<Atribut> atributs){
        if (!items.containsKey(idItem)) return false;
        items.get(idItem).modificaItem(atributs);
        return true;
    }

    public static boolean eliminaItem(int idItem){
        if (!items.containsKey(idItem)) return false;
        items.remove(idItem);
        return true;
    }

    public static void setItem(Integer id, Item item) {
        items.put(id, item);
    }

    /**
     * Valoracions
     */

    public static boolean creaValoracio(int idUsuari, int idItem, double puntuacio, String descripcio) throws Excepcions.InvalidPuntuacioException, Excepcions.InvalidValoracioException {
        if (!items.containsKey(idItem) || items.get(idItem).usuariJaHaValorat(idUsuari)) return false;
        Valoracio valoracio = new Valoracio(idUsuari, puntuacio, descripcio, items.get(idItem));
        items.get(idItem).addValoracio(valoracio);
        usuaris.get(idUsuari).add_item_valoracio(valoracio);
        //S'hauria de crear una valoració amb els paràmetres que es passen i després afegir la valoració.
        return true;
    }

    public static boolean editaValoracio(int idUsuari, int idItem, Double puntuacio, String descripcio){
        if (!items.containsKey(idItem) || !items.get(idItem).usuariJaHaValorat(idUsuari)) return false;
        items.get(idItem).setValoracio(puntuacio,descripcio);
        usuaris.get(idUsuari).setValoracio(idItem,puntuacio,descripcio);
        return true;
    }

    public static boolean eliminaValoracio(int idUsuari, int idItem){
        if (!items.containsKey(idItem) || !items.get(idItem).usuariJaHaValorat(idUsuari)) return false;
        items.get(idItem).removeValoracio(idUsuari);
        usuaris.get(idUsuari).removeValoracio(idItem);
        return true;
    }


    /**
     * Usuaris
     */

    public static void inicia_sesio_usuari_actiu (int id, string contrasenya) throws UsuariExceptions {
        if (usuariActiu != null) {
            throw new UsuariExceptions("Ja hi ha una sessió iniciada amb un usuari. Primer tanca la sessió");
        }

        if (usuaris.containsKey(id) == false) {
            throw new UsuariExceptions("No hi ha cap usuari amb aquest identificador");
        }

        if (usuaris.get(id).is_actiu() == false) {
            throw new UsuariExceptions("L'usuari amb aquest identificador no és actiu, i per tant no es pot iniciar sessió amb aquest");
        }

        if (((U_Actiu) usuaris.get(id)).get_contrasenya() != contrasenya) {
            throw new UsuariExceptions("Contrasenya incorrecta");
        }

        usuariActiu = (U_Actiu) usuaris.get(id);
        usuaris.remove(id);

    }


    public static void tanca_sesio_usuari_actiu () throws UsuariExceptions {
        if (usuariActiu == null) {
            throw new UsuariExceptions("No hi ha cap sessió oberta de cap usuari")
        }
        usuaris.put(usuariActiu.get_id(), usuariActiu);
        usuariActiu = null;

    }


    public static boolean creaUsuariActiu(String nom, String password) throws UsuariExceptions {  //ES CREA UN IDENTIFICADOR RANDOM
        int id; 
        do {  //agafem un id no usat
            id = randoms.random_int(0, (Integer.MAX_VALUE-2));  
        } while (usuaris.containsKey(id)); 

        U_Actiu uactiu = new U_Actiu(id, nom, password);
        usuaris.put(id, uactiu);
        return true;
    }

    public static void creaUsuariNoActiu(int id) throws UsuariExceptions {
        if (usuaris.containsKey(id)) throw new UsuariExceptions("Un usuari amb el mateix identificador ja existeix");
        Usuari usuari = new Usuari(id);
        usuaris.put(id, usuari);
    }

    public static void eliminaUsuari(int id) throws UsuariExceptions { //Aquí als casos d'ús hauria de sortir del compte quan s'elimina l'usuari.
        if (!usuaris.containsKey(id)) throw new UsuariExceptions("No existeix cap usuari amb aquest identificador");
        if (usuaris.get(id) == usuariActiu) {
            usuariActiu = null;
        }
        usuaris.remove(id);
    }

    public static void modificaUsuariActiu (int id, String nom, String password) throws UsuariExceptions{
        if (!usuaris.containsKey(id)) throw new UsuariExceptions("No existeix cap usuari amb aquest identificador");
        usuaris.get(id).canvia_nom(nom); // S'hauria de poder modificar el nom d'un usuari actiu??
        ((U_Actiu)usuaris.get(id)).canvia_password(password); //No deixa accedir
    }

    /**
     * Getters
     */


    public static ArrayList<Item> getItemsUsuari(int idUsuari) throws UsuariExceptions {
        if (!usuaris.containsKey(idUsuari)) throw new UsuariExceptions("No existeix cap usuari amb aquest identificador");
        return usuaris.get(idUsuari).getItemsValorats();
    }

    /**
     * Setters
     */


}