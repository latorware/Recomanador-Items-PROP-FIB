package controladors;

public class CtrlGuardaDades {
    public static void carregaItems() {
    }

    public static void carregaValoracions() {
    }

    public static void guardaRecomanacio() {
    }
}
