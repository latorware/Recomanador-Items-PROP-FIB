package controladors;

import domini.*;


public class CtrlRecomanacio {

    public static void creaRecomanacio() {
    }

    public static void valoraRecomanacio() {
    }
}
