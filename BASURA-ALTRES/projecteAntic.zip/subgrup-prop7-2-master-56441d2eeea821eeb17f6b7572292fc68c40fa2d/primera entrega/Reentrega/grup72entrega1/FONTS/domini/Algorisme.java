package domini; 

public class Algorisme {
    
}