package domini;

import domini.Excepcions.ItemNul;
import domini.Excepcions.TipusAtributNul;

public class AtrBool extends Atribut {

    /**
     * Atributs
     */
    private boolean atributBool;

    /**
     * Constructor
     * @throws TipusAtributNul
     */
    public AtrBool(TipusAtribut tipus, boolean bool) throws TipusAtributNul
    {
        super(tipus);
        atributBool = bool;
    }

    public AtrBool(Item item, TipusAtribut tipus, boolean bool) throws ItemNul, TipusAtributNul
    {
        super(item, tipus);
        atributBool = bool;
    }
    /**
     * Getters
     */
    public boolean getAtributBool() {
        return atributBool;
    }
}