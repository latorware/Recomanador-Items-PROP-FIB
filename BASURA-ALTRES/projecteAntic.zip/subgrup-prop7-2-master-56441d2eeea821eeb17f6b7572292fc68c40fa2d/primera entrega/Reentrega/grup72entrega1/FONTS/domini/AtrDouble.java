package domini;

import domini.Excepcions.ItemNul;
import domini.Excepcions.TipusAtributNul;

public  class AtrDouble extends Atribut {

    /**
     * Atributs
     */
    private double atributDouble;

    /**
     * Constructor
     * @throws TipusAtributNul
     */
    public AtrDouble(TipusAtribut tipus, double numero) throws TipusAtributNul
    {
        super(tipus);
        atributDouble = numero;
    }

    public AtrDouble(Item item, TipusAtribut tipus, double numero) throws ItemNul, TipusAtributNul
    {
        super(item, tipus);
        atributDouble = numero;
    }

    /**
     * Getters
     */
    public double getAtributDouble() {
        return atributDouble;
    }
}