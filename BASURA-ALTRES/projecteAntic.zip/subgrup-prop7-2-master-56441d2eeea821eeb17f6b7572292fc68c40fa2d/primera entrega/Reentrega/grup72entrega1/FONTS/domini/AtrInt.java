package domini;

import domini.Excepcions.ItemNul;
import domini.Excepcions.TipusAtributNul;

public  class AtrInt extends Atribut {

    /**
     * Atributs
     */
    private int atributInt;

    /**
     * Constructor
     * @throws TipusAtributNul
     */
    public AtrInt(TipusAtribut tipus, int numero) throws TipusAtributNul
    {
        super(tipus);
        atributInt = numero;
    }

    public AtrInt(Item item, TipusAtribut tipus, int numero) throws ItemNul, TipusAtributNul
    {
        super(item, tipus);
        atributInt = numero;
    }

    /**
     * Getters
     */
    public int getAtributInt() {
        return atributInt;
    }
}