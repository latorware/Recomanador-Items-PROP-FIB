package domini;

import domini.Excepcions.ItemNul;
import domini.Excepcions.TipusAtributNul;
import domini.Excepcions.ValorAtributNul;

public  class AtrString extends Atribut {

    /**
     * Atributs
     */
    private String atributString;

    /**
     * Constructor
     * @throws TipusAtributNul
     */
    public AtrString(TipusAtribut tipus, String text) throws TipusAtributNul, ValorAtributNul
    {
        super(tipus);
        if (text == null) throw new ValorAtributNul(); 
        atributString = text;
    }

    public AtrString(Item item, TipusAtribut tipus, String text) throws ItemNul, TipusAtributNul, ValorAtributNul
    {
        super(item, tipus);
        if (text == null) throw new ValorAtributNul(); 
        atributString = text;
    }

    /**
     * Getters
     */
    public String getAtributString() {
        return atributString;
    }
}