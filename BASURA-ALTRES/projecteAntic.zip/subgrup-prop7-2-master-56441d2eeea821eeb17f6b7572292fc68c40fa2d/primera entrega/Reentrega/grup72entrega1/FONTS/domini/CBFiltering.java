package domini;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.*;

import domini.Excepcions.InsuficientsValoracionsExcepcio;
import domini.Excepcions.InsuficientsItemsNoValoratsExcepcio;
import domini.Excepcions.InsuficientsItemsExcepcio;;


public class CBFiltering extends Algorisme{

    //Input i output: userid((itemid1,rating1),..., (itemidn,ratingn)),idtemid1',...,itemidn', Q
    //donada una query i,((j1,K[i][j1]),...,(jd,K[i][jd])),j1',...,jd', Q

    /*Eliminem Ks que tinguin valor massa baix, de forma que queden d' <= d elements. Seguidament, per cada (j,K[i][j])
     computem els k elements més propers a j d'entre j'1,...,j'd i produïm (S,K[i][j]) on S és un subset de k elements
     de j1',...,jd'.
     */
    /*Això ens crea una colecció de parelles (s1,v1),...,(sd,vd), finalment ordenem j1',...,jd' en ordre depenent de
    quantes vegades apareixen en els subsets i tenint en compte els values (si els ha agradat més o menys)*/

    //private HashMap<Item, Valoracio> itemsUsuari;

    private Usuari usuari; 
    private HashMap<Item, HashMap<Item, Double>> totesDistancies;
    
    public CBFiltering(Usuari usuari, HashMap<Item, HashMap<Item, Double>> totesDistancies){
        this.usuari = usuari;
        this.totesDistancies = totesDistancies;
    }

    public ArrayList<Item> knn (int k) throws InsuficientsValoracionsExcepcio, InsuficientsItemsExcepcio, InsuficientsItemsNoValoratsExcepcio{
        if (usuari.getItemsValoracions().isEmpty()) throw new InsuficientsValoracionsExcepcio();
        if(totesDistancies.isEmpty()) throw new InsuficientsItemsExcepcio();
        double distMax = 20;
        HashMap<Item, Valoracio> valoradesBones = new HashMap<Item, Valoracio>(); //Item, Puntuacio
        HashMap<Item, Double> posicions = new HashMap<>();
        ArrayList<Item> recomanacions = new ArrayList<>(); 
    

            for (HashMap.Entry<Item, Valoracio> entry : usuari.getItemsValoracions().entrySet()) {
                Item item = entry.getKey();
                Valoracio val = entry.getValue();
                if (val.getPuntuacio() >= 3) valoradesBones.put(item, val);
            }

            if(valoradesBones.size() == 0 ){
                for (HashMap.Entry<Item, Valoracio> entry : usuari.getItemsValoracions().entrySet()) {
                    Item item = entry.getKey();
                    Valoracio val = entry.getValue();
                    if (val.getPuntuacio() >= 2) valoradesBones.put(item, val);
                }    
            }
            if(valoradesBones.size() == 0 ){
                for (HashMap.Entry<Item, Valoracio> entry : usuari.getItemsValoracions().entrySet()) {
                    Item item = entry.getKey();
                    Valoracio val = entry.getValue();
                    if (val.getPuntuacio() >= 1) valoradesBones.put(item, val);
                }    
            }

            
                        
            //Calcula la distància a la resta d'items per cada item que tinc jo
            for (HashMap.Entry<Item, Valoracio> entry : valoradesBones.entrySet()) {
                Item item1 = entry.getKey();
                Double puntuacio = entry.getValue().getPuntuacio();
                HashMap<Item, Double> distancies = totesDistancies.get(item1);

                for (HashMap.Entry<Item, Double> entry2 : distancies.entrySet()) {
                    Item item2 = entry2.getKey();

                    //Si no és la mateixa i no està valorada busca la distància
                    if (item1.getID() != item2.getID() && !usuari.getItemsValoracions().containsKey(item2)) {
                        double dist = entry2.getValue();
                        
                        if (dist < distMax) {
                            if (posicions.containsKey(item2)) {
                                //Continuo pensant que no és correcte, 
                                double valor = posicions.get(item2);
                                //valor = valor + (distMax-dist)/distMax*puntuacio;
                                valor = valor + puntuacio ;
                                
                                posicions.put(item2, valor);
                            } else posicions.put(item2, puntuacio);
                        }
                    }
                    // Aqui ja tindrem un conjunt de llistes amb una forma semblant a (S,K[i][j])
                    // en principi també he comptat quantes vegades apareixen i enlloc de sumar 1 suma la seva puntuacio
                }
            }

            if(posicions.isEmpty()) throw new InsuficientsItemsNoValoratsExcepcio();
     

        
        //Ara ordenaré i eliminaré les que sobrin
        
        double max=0;
        Item iaux = new Item();

        for(int i = 0; i < k; i++){
            for(Map.Entry<Item, Double> entry : posicions.entrySet()) {
                if(entry.getValue() > max){
                    max = entry.getValue();
                    iaux = entry.getKey();
                }
            }
            if(max != 0 && (iaux.getID() != -1)){
                max = 0;
                recomanacions.add(iaux);
                posicions.remove(iaux);
            }
            else i = k;
        }
        return recomanacions;
    }
}
