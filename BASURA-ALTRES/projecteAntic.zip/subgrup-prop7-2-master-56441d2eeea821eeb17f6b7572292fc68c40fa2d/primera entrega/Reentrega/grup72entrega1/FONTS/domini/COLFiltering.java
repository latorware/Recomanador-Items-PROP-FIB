package domini;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class COLFiltering {

    //Donat un usuari, retorna una sèrie de items que se li recomanen segons el collaborative filtering, el qual
    //consta dels algorismes k-Means i SlopeOne


    private HashMap<Integer,Usuari> usuaris;
    private HashMap<Integer,HashMap<Integer,Double>> distancies;
    private int k;


    public COLFiltering(HashMap<Integer,Usuari> usuaris, int k) throws Excepcions.UsuariAAfegirEsAnalitzat,
            Excepcions.UsuariNul, Excepcions.UsuariJaAfegit, Excepcions.SetUsuarisNul {
        this.usuaris = new HashMap<>(usuaris);
        calcularDistancies();
        if (k > usuaris.size() || k <= 0) this.k = 3;
        this.k = k;
    }

    private void calcularDistancies() throws Excepcions.UsuariAAfegirEsAnalitzat, Excepcions.UsuariNul,
            Excepcions.UsuariJaAfegit, Excepcions.SetUsuarisNul {

        distancies = new HashMap<>();
        for (HashMap.Entry<Integer,Usuari> entry : usuaris.entrySet()) {
            HashSet<Usuari> us = new HashSet<>(usuaris.values());
            us.remove(usuaris.get(entry.getKey()));
            DistUsuari dist = new DistUsuari(entry.getValue(),us);

            HashMap<Usuari,Double> distancia = new HashMap<>(dist.getDistancies());
            HashMap<Integer,Double> intDoub = new HashMap<>();

            for (HashMap.Entry<Usuari,Double> entry2 : distancia.entrySet()) {
                if (entry.getKey() == entry2.getKey().getId()){
                    intDoub.put(entry2.getKey().getId(), 0.0);
                }
                else intDoub.put(entry2.getKey().getId(), entry2.getValue());
            }
            distancies.put(entry.getKey(),intDoub);
        }
    }



    public ArrayList<Item> recomanacions(Usuari usuari) throws Excepcions.MassaClustersExcepcio, Excepcions.CapClusterExcepcio {
        ArrayList<Item> recomanacions = new ArrayList<>();

        KMeans kmeans = new KMeans(distancies);
        kmeans.calcularClusters(k);

        //Usuaris mateix cluster
        HashSet<Integer> clusters = new HashSet<>(kmeans.usuarisMateixCluster(usuari));

        HashMap<Integer, Usuari> usuarisVeins = new HashMap<>();
        for (Integer entry : clusters) {
            usuarisVeins.put(entry, usuaris.get(entry));
        }

        HashSet<Item> itemsAValorar = new HashSet<>();
        for (Integer entry : clusters) {
            HashMap<Item, Valoracio> itemsValorats = new HashMap<>(usuaris.get(entry).getItemsValoracions());
            for (HashMap.Entry<Item, Valoracio> entry2 : itemsValorats.entrySet()) {
                if (!usuari.getItemsValoracions().containsKey(entry2.getKey())) itemsAValorar.add(entry2.getKey());
            }
        }

        HashMap<Item, Double> mapRatings = new HashMap<>();

        SlopeOne slopeOne = new SlopeOne(usuari, usuarisVeins);

        for (Item entry : itemsAValorar) {
            double ratingRecomanacio = slopeOne.prediccio(entry);

            mapRatings.put(entry, ratingRecomanacio);
            int j;
            for (j = 0; j < recomanacions.size(); ++j) {
                if (ratingRecomanacio > mapRatings.get(recomanacions.get(j))) {
                    break;
                }
            }
            recomanacions.add(j, entry);
        }
        return recomanacions;
    }

}
