package domini;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

public class DCG {

    private double DCG;
    private double IDCG;
    private double NDCG;
    private HashMap<Item,Double> LT;
    private ArrayList<Item> LR;


    public DCG(HashMap<Item,Double> LT, ArrayList<Item> LR) {
        DCG = 0;
        IDCG = 0;
        NDCG = 0;
        this.LT = new HashMap<>(LT);
        this.LR = new ArrayList<>(LR);
    }

    public void calculaDGC() {
        int i = 1;
        ArrayList<Double> ltOrdenada = new ArrayList<>(LT.values());
        ltOrdenada.sort(Collections.reverseOrder());
        for (Item entry : LR) {
            double relI = 0;
            if (LT.containsKey(entry)) relI = LT.get(entry);
            double potenciaRel = (Math.pow(2,relI) - 1) / (Math.log10(i+1) / Math.log10(2));
            double potenciaRelI = (Math.pow(2, ltOrdenada.get(i-1)) - 1) / (Math.log10(i+1) / Math.log10(2));
            DCG += potenciaRel;
            IDCG += potenciaRelI;
            i += 1;
        }
        NDCG = DCG / IDCG;

    }

    public double getDCG() {
        return DCG;
    }

    public double getIDCG() {
        return IDCG;
    }

    public double getNDCG() {
        return NDCG;
    }
}
