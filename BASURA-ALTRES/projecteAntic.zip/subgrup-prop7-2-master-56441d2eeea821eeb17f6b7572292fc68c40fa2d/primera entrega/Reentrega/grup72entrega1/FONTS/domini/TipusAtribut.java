package domini;

import java.util.HashSet;
import java.util.Set;

import domini.Excepcions.*;

public class TipusAtribut {

    /**
     * Atributs
     */
    private String nom;
    private boolean calculable;
    private Set<Atribut> atributs = new HashSet<>();
    private double max;
    private double min;
    private String tipusDada;
    private boolean MaxMinInicialitzats = false; 

    /**
     * Getters
     */
    public boolean getCalculable() {
        return calculable;
    }

    public String getNom() {
        return nom;
    }

    /**
     * Constructor
     */
    public TipusAtribut(String nom, String tipusDada) throws Excepcions.IncompatibleTipusAtribut, NomNul, TipusDadaNul
    {
        if (tipusDada == null) throw new TipusDadaNul (); 
        if (nom == null) throw new NomNul(); 
        if ((tipusDada.equals("Int")) || (tipusDada.equals("Double")) || (tipusDada.equals("String")) || (tipusDada.equals("Bool")))
        {
            this.tipusDada = tipusDada;
        }
        else {
            throw new IncompatibleTipusAtribut (); 
        }
        this.nom = nom;
        /* Quan creem el tipus, posem tots a false perquè després l'usuari actiu decidirà si es true */
        calculable = false;
        max = -1;
        min = -1;
    }

    /**
     * Setters
     */
    public void setCalculable(boolean calculable) {
        this.calculable = calculable;
    }


    /**
     * 
     * @param atribut
     */
    public void afegirAtribut(Atribut atribut) throws AtributNul
    {
        if (atribut == null) throw new AtributNul (); 
        if (this.tipusDada.equals("Int"))
        {   
            int num = ((AtrInt)atribut).getAtributInt();
            if (!MaxMinInicialitzats) {
                max = num;
                min = num; 
                MaxMinInicialitzats = true; 
            }
            else {
                
                if (num > max) max = num;
                else if (num < min) min = num;
            }

        }
        else if (this.tipusDada.equals("Double"))
        {
            double num = ((AtrDouble)atribut).getAtributDouble();
            if (!MaxMinInicialitzats) {
                max = num;
                min = num; 
                MaxMinInicialitzats = true; 
            }
            else {
                
                if (num > max) max = num;
                else if (num < min) min = num;
            }

        }

        atributs.add(atribut); 
    }


    /**
     * 
     * @param atribut
     */
    public void eliminaAtribut(Atribut atribut) throws AtributNul
    {
        if (atribut == null) throw new AtributNul (); 
        if (this.tipusDada.equals("Int"))
        {
            int num = ((AtrInt)atribut).getAtributInt();
            if (num == max)
            {
                max = -1;
                this.atributs.remove(atribut);
                for (Atribut a : atributs) {
                    num = ((AtrInt)a).getAtributInt();
                    if (num > max) max = num;
                }
            }
            if (num == min)
            {
                min = -1;
                this.atributs.remove(atribut);
                boolean primer = true; 
                for (Atribut a : atributs) {
                    num = ((AtrInt)a).getAtributInt();
                    if (primer) {
                        min = num; 
                        primer = false; 
                    }
                    if (num < min) min = num;
                }
            }
            this.atributs.remove(atribut); 
        }
        else if (this.tipusDada.equals("Double"))
        {
            double num = ((AtrDouble)atribut).getAtributDouble();
            if (num == max)
            {
                max = -1;
                this.atributs.remove(atribut);
                for (Atribut a : atributs) {
                    num = ((AtrDouble)a).getAtributDouble();
                    if (num > max) max = num;
                }
            }
            if (num == min)
            {
                min = -1; 
                this.atributs.remove(atribut);
                boolean primer = true; 
                for (Atribut a : atributs) {
                    num = ((AtrDouble)a).getAtributDouble();
                    if (primer) {
                        min = num; 
                        primer = false; 
                    }
                    if (num < min) min = num;
                }
            }
            this.atributs.remove(atribut); 
        }
        else {
            this.atributs.remove(atribut); 
        }
    }


    /**
     * 
     */
    public double getMaxValor() {
        return max; 
    }


    /**
     * 
     * @return
     */
    public double getMinValor() {
        return min; 
    }


    /**
     * 
     * @return
     */
    public String getTipusDada () {
        return tipusDada; 
    }


    public Set<Atribut> getAtributs () {
        return atributs; 
    }
}