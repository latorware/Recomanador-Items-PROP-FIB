package persistencia;

import java.io.*;
import java.util.*;

import domini.*;
import utils.Pair;

public class DataReader
{
    public static final String SEPARADOR = ",";

    public static boolean Negative(String s)
    {
        if (!Objects.equals(s, ""))
        {
            return s.charAt(0) == '-';
        }
        return false;
    }

    public static boolean isInteger(String s)
    {
        if (!Objects.equals(s, ""))
        {
            for(int i = 0; i < s.length(); i++) {
                if(i == 0 && s.charAt(i) == '-') {
                    if(s.length() == 1) return false;
                    else continue;
                }
                if(s.charAt(i) > 57 || s.charAt(i) < 48) return false;
            }
            return true;
        }
        else return false;
    }

    public static boolean isDouble(String s)
    {
        if (!Objects.equals(s, ""))
        {
            for(int i = 0; i < s.length(); i++) {
                if(i == 0 && s.charAt(i) == '-') {
                    if(s.length() == 1) return false;
                    else continue;
                }
                if (s.charAt(i) != 46)
                {
                    if (s.charAt(i) > 57 || s.charAt(i) < 48) return false;
                }
            }
            return true;
        }
        else return false;
    }

    public static boolean isBoolean(String string)
    {
        return string.equals("False") || string.equals("false") || string.equals("True") || string.equals("true");
    }

    public static boolean transformarBoolean(String string)
    {
        return !string.equals("False") && !string.equals("false");
    }

    public static int comptarQuotes(String string)
    {
        int quotesCount = 0;
        char temp;
        for (int i = 0; i < string.length(); i++) {
            temp = string.charAt(i);
            if (temp == '"')
                quotesCount++;
        }
        return quotesCount;
    }

    public static ArrayList<ArrayList<String>> llegeixHeader(String direccioArxiu)
    {
        ArrayList<ArrayList<String>> linies = new ArrayList<>();
        BufferedReader bufferLectura = null;

        try {
            // Abrir el .csv en buffer de lectura
            bufferLectura = new BufferedReader(new FileReader(direccioArxiu));
            // Leer una linea del archivo
            String linea = bufferLectura.readLine();
            int i = 0;
            while (i < 3) {
                // Sepapar la linea leída con el separador definido previamente
                String[] campos = linea.split(SEPARADOR);
                ArrayList<String> l = new ArrayList<>(Arrays.asList(campos));
                linies.add(l);
                // Volver a leer otra línea del fichero
                linea = bufferLectura.readLine();
                ++i;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            // Cierro el buffer de lectura
            if (bufferLectura != null) {
                try {
                    bufferLectura.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return linies;
    }

    public static ArrayList<ArrayList<String>> llegeixItems(String direccioArxiu)
    {
        BufferedReader bufferLectura = null;
        ArrayList<ArrayList<String>> linies = new ArrayList<>();
        try {
            // Abrir el .csv en buffer de lectura
            bufferLectura = new BufferedReader(new FileReader(direccioArxiu));
            // Leer una linea del archivo
            String linea = bufferLectura.readLine();

            while (linea != null) {
                // Sepapar la linea leída con el separador definido previamente
                String[] campos = linea.split(SEPARADOR);
                ArrayList<String> l = new ArrayList<>(Arrays.asList(campos));
                linies.add(l);
                // Volver a leer otra línea del fichero
                linea = bufferLectura.readLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            // Cierro el buffer de lectura
            if (bufferLectura != null) {
                try {
                    bufferLectura.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return linies;
    }

    public static String comprovaValor(int j, String pathI)
    {
        String s = "";
        ArrayList<ArrayList<String>> header = llegeixItems(pathI);
        Iterator<ArrayList<String>> outerIterator = header.listIterator();
        int i = 0;
        int l = 0;
        boolean quotesL = false;
        boolean trobat = false;
        String paraulaAAjuntar = "";
        while (outerIterator.hasNext() && !trobat)
        {
            Iterator<String> innerIterator = outerIterator.next().listIterator();
            boolean quotes = false;
            while (innerIterator.hasNext() && !trobat)
            {
                String word = innerIterator.next();

                Iterator<ArrayList<String>> it = header.iterator();
                ArrayList<String> array = it.next();
                if (l > 1)
                {
                    if (isBoolean(word))
                    {
                        if (i == j)
                        {
                            s = word;
                            trobat = true;
                        }
                        ++i;
                    }
                    else if (isInteger(word) && !Negative(word))
                    {
                        if (i == j)
                        {
                            s = word;
                            trobat = true;
                        }
                        ++i;
                    }
                    else if (isDouble(word) && !Negative(word))
                    {
                        if (i == j)
                        {
                            s = word;
                            trobat = true;
                        }
                        ++i;
                    }
                    else if (!word.equals("") && !Negative(word))//és String
                    {
                        char lastCharacter = word.charAt(word.length() - 1);
                        char firstChar = word.charAt(0);
                        int charQuotes = comptarQuotes(word);
                        if ((firstChar != lastCharacter && firstChar == '"' && !quotes) || (firstChar == lastCharacter && firstChar == '"' && charQuotes%2==1 && !quotes)) {//Primer amb " i ultim char sense "
                            quotes = true;
                            quotesL = true;
                            paraulaAAjuntar = word;
                        }
                        else if (!word.contains("\"") && quotes || !word.contains("\"") && !quotes && quotesL)//Paraules entre " "
                        {
                            paraulaAAjuntar = paraulaAAjuntar.concat("," + word);
                        }
                        else if (word.contains("\"") && quotes || word.contains("\"") && !quotes && quotesL) {//Paurala entre " " amb "
                            if (charQuotes%2==1)
                            {
                                quotes = false;
                                quotesL = false;
                                paraulaAAjuntar = paraulaAAjuntar.concat("," + word);
                                if (i == j)
                                {
                                    s = word;
                                    trobat = true;
                                }
                                ++i;
                            }
                        }
                        else
                        {
                            if (i == j)
                            {
                                s = word;
                                trobat = true;
                            }
                            ++i;
                        }
                    }
                    else ++i;
                }
            }
            i = 0;
            ++l;
        }
        return s;
    }

    public static void carregaDades(Map<String, TipusAtribut> tipusAtribut, Map<Integer, Item> items, Map<Integer, Usuari> usuaris,Map<Pair<Item, Usuari>, Valoracio> valoracions,HashMap<Integer, HashMap<Integer, Double>> unknown) throws Exception
    {
        Scanner scanner = new Scanner(System.in);
        String input = "";
        System.out.println("Programa en execucio.\n" +
                "Analitzant csv.\n" +
                "Vols indicar el path dels arxius CSV? En cas de que no, utilitzarem els CSV que te el directori \"data\".\n" +
                "Escriu \"Si\" o \"No\":");
        while (!input.equals("Si") && !input.equals("No")) {
            input = scanner.nextLine();
        }
        String pathI;
        String pathU;
        String pathUnknown;
        if (input.equals("Si"))
        {
            scanner = new Scanner(System.in);
            input = "";
            boolean correcteI = false;
            boolean correcteU = false;
            boolean correcteUnknown = false;
            System.out.println("Escriu el path del directori:");
            while (!correcteI && !correcteU && ! correcteUnknown) {
                input = scanner.nextLine();
                File arxiuI = new File(input + "items.csv");
                File arxiuU = new File(input + "ratings.test.known.csv");
                File arxiuUnknown = new File(input + "ratings.test.unknown.csv");
                correcteI = arxiuI.exists();
                correcteU = arxiuU.exists();
                correcteUnknown = arxiuUnknown.exists();
                if (!correcteI) System.out.println("L'arxiu \"items.csv\" no existeix al path indicat.");
                if (!correcteU) System.out.println("L'arxiu \"ratings.test.know.csv\" no existeix al path indicat.");
                if (!correcteUnknown) System.out.println("L'arxiu \"ratings.test.unknown.csv\" no existeix al path indicat.");
            }
            pathI = input;
            pathU = input;
            pathUnknown = input;

        }
        else
        {
            pathI = System.getProperty("user.dir") + "/data/movies.sample/250/items.csv";
            pathU = System.getProperty("user.dir") + "/data/movies.sample/250/ratings.test.known.csv";
            pathUnknown = System.getProperty("user.dir") + "/data/movies.sample/250/ratings.test.unknown.csv";
        }

        ArrayList<TipusAtribut> tipusAtributArray = new ArrayList<>(); //Array TIPUSATRIBUT
        ArrayList<Integer> ids = new ArrayList<>(); //Array IDS

        int posicioId = 0;
        /*
        Lectura header
         */
        ArrayList<ArrayList<String>> header = llegeixHeader(pathI);
        Iterator<ArrayList<String>> outerIterator = header.listIterator();
        int i = 0;
        boolean quotesL = false;
        int l = 0;
        boolean correcte = true;
        boolean acabat = false;
        while (outerIterator.hasNext())
        {
            Iterator<String> innerIterator = outerIterator.next().listIterator();
            boolean quotes = false;
            while (innerIterator.hasNext() && !acabat)
            {
                String word = innerIterator.next();
                Iterator<ArrayList<String>> it = header.iterator();
                ArrayList<String> array = it.next();
                if (l == 1)
                {
                    if (isBoolean(word))
                    {
                        tipusAtributArray.add(new TipusAtribut(array.get(i), "Bool"));
                        ++i;
                    }
                    else if (isInteger(word) && !Negative(word))
                    {
                        if (!array.get(i).equals("id"))
                        {
                            tipusAtributArray.add(new TipusAtribut(array.get(i), "Int"));
                        }
                        else posicioId=i;
                        ++i;
                    }
                    else if (isDouble(word) && !Negative(word))
                    {
                        tipusAtributArray.add(new TipusAtribut(array.get(i), "Double"));
                        ++i;
                    }
                    else if (!word.equals("") && !Negative(word))//és String
                    {
                        char lastCharacter = word.charAt(word.length() - 1);
                        char firstChar = word.charAt(0);
                        int charQuotes = comptarQuotes(word);
                        if ((firstChar != lastCharacter && firstChar == '"' && !quotes) || (firstChar == lastCharacter && firstChar == '"' && charQuotes%2==1 && !quotes)) {//Primer amb " i ultim char sense "
                            quotes = true;
                            quotesL = true;
                        }
                        else if (word.contains("\"") && quotes) //Paurala entre " " amb "
                        {
                            if (charQuotes%2==1)
                            {
                                quotes = false;
                                quotesL = false;
                                tipusAtributArray.add(new TipusAtribut(array.get(i), "String"));
                                ++i;
                            }
                        }
                        else if (!(!word.contains("\"") && quotes))
                        {
                            tipusAtributArray.add(new TipusAtribut(array.get(i), "String"));
                            ++i;
                        }
                    }
                    else // word.equals("")
                    {
                        word = comprovaValor(i, pathI);
                        if (!word.equals(""))
                        {
                            if (isBoolean(word))
                            {
                                tipusAtributArray.add(new TipusAtribut(array.get(i), "Bool"));
                                ++i;
                            }
                            else if (isInteger(word) && !Negative(word))
                            {
                                if (!array.get(i).equals("id"))
                                {
                                    tipusAtributArray.add(new TipusAtribut(array.get(i), "Int"));
                                }
                                else posicioId=i;
                                ++i;
                            }
                            else if (isDouble(word) && !Negative(word))
                            {
                                tipusAtributArray.add(new TipusAtribut(array.get(i), "Double"));
                                ++i;
                            }
                            else if (!Negative(word))//és String
                            {
                                char lastCharacter = word.charAt(word.length() - 1);
                                char firstChar = word.charAt(0);
                                int charQuotes = comptarQuotes(word);
                                if ((firstChar != lastCharacter && firstChar == '"' && !quotes) || (firstChar == lastCharacter && firstChar == '"' && charQuotes%2==1 && !quotes)) {//Primer amb " i ultim char sense "
                                    quotes = true;
                                    quotesL = true;
                                }
                                else if (word.contains("\"") && quotes) //Paurala entre " " amb "
                                {
                                    if (charQuotes%2==1)
                                    {
                                        quotes = false;
                                        quotesL = false;
                                        tipusAtributArray.add(new TipusAtribut(array.get(i), "String"));
                                        ++i;
                                    }
                                }
                                else if (!(!word.contains("\"") && quotes))
                                {
                                    tipusAtributArray.add(new TipusAtribut(array.get(i), "String"));
                                    ++i;
                                }
                            }
                        }
                        else
                        {
                            Scanner scan = new Scanner(System.in);
                            String inp = "";
                            System.out.println("\nNo hem pogut deduir de quin tipus es " + array.get(i) + ". Digues si es un \"Bool\", \"Int\", \"Double\" o \"String\":");
                            while (!inp.equals("Bool") && !inp.equals("Int") && !inp.equals("Double") && !inp.equals("String")) {
                                inp = scan.nextLine();
                            }
                            tipusAtributArray.add(new TipusAtribut(array.get(i), inp));
                            ++i;
                        }
                    }
                }
                else if (l == 2)
                {
                    if (quotesL) correcte = false;
                    acabat = true;
                }
            }
            i = 0;
            ++l;
        }

        if (!correcte) throw new Excepcions.SaltDeLiniaExcepcio();
        else System.out.println();

        //Omplim MAP de TipusAtribut
        for (TipusAtribut atribut : tipusAtributArray) {
            String nom = atribut.getNom();
            Scanner scan = new Scanner(System.in);
            String inp = "";
            System.out.println("Vols que es calculin recomanacions en funcio de \"" + nom + "\"?\n" + "Escriu \"Si\" o \"No\":");
            while (!inp.equals("Si") && !inp.equals("No")) {
                inp = scan.nextLine();
            }
            atribut.setCalculable(inp.equals("Si"));
            tipusAtribut.put(nom, atribut);
        }

        /*
        Lectura items
         */
        ArrayList<ArrayList<String>> atributsItems = DataReader.llegeixItems(pathI);
        Iterator<ArrayList<String>> linias = atributsItems.listIterator();
        int i2 = 0;
        int linia = 0;
        int saveLinia = 0;
        String paraulaAAjuntar = "";
        boolean quotesLinia = false;
        while (linias.hasNext())
        {
            Iterator<String> paraules = linias.next().listIterator();
            boolean quotes = false;
            boolean trobat = false;
            Set<Atribut> atributsItem = new HashSet<>();
            while (paraules.hasNext())
            {
                String word = paraules.next();
                if (i2 == posicioId && trobat) trobat = false;
                else if (i2 == posicioId) trobat = true;
                if (linia > 0)
                {
                    if (!Objects.equals(word, "") && i2 < tipusAtributArray.size() && !trobat)
                    {
                        String tipus = tipusAtributArray.get(i2).getTipusDada();
                        if (Objects.equals(tipus, "Bool") && !quotesLinia)
                        {
                            if (isBoolean(word))
                            {
                                boolean b = transformarBoolean(word);
                                AtrBool nou = new AtrBool(tipusAtributArray.get(i2), b);
                                tipusAtribut.get(tipusAtributArray.get(i2).getNom()).afegirAtribut(nou);//Afegir Atribut al Set<Atribut> del TIPUS
                                atributsItem.add(nou);
                                ++i2;
                            }
                        }
                        else if (Objects.equals(tipus, "Int") && !quotesLinia)
                        {
                            if (isInteger(word))
                            {
                                int num = 0;
                                if (!Negative(word)) num = Integer.parseInt(word);
                                AtrInt nou = new AtrInt(tipusAtributArray.get(i2), num);
                                tipusAtribut.get(tipusAtributArray.get(i2).getNom()).afegirAtribut(nou);
                                atributsItem.add(nou);
                                ++i2;
                            }
                        }
                        else if (Objects.equals(tipus, "Double") && !quotesLinia)
                        {
                            if (isDouble(word))
                            {
                                double num = 0.0;
                                if (!Negative(word)) num = Double.parseDouble(word);
                                AtrDouble nou = new AtrDouble(tipusAtributArray.get(i2), num);
                                tipusAtribut.get(tipusAtributArray.get(i2).getNom()).afegirAtribut(nou);
                                atributsItem.add(nou);
                                ++i2;
                            }
                        }
                        else
                        {//és String
                            if (!isDouble(word) && !isInteger(word) && !isBoolean(word))
                            {
                                char lastCharacter = word.charAt(word.length() - 1);
                                char firstChar = word.charAt(0);
                                int charQuotes = comptarQuotes(word);
                                if ((firstChar != lastCharacter && firstChar == '"' && !quotes) || (firstChar == lastCharacter && firstChar == '"' && charQuotes%2==1 && !quotes)) {//Primer amb " i ultim char sense "
                                    quotes = true;
                                    quotesLinia = true;
                                    saveLinia = linia;
                                    paraulaAAjuntar = word;
                                }
                                else if (!word.contains("\"") && quotes && quotesLinia || !word.contains("\"") && !quotes && quotesLinia)//Paraules entre " "
                                {
                                    paraulaAAjuntar = paraulaAAjuntar.concat("," + word);
                                }
                                else if (word.contains("\"") && quotes || word.contains("\"") && !quotes && quotesLinia) {//Paurala entre " " amb "
                                    if (charQuotes%2==1)
                                    {
                                        quotes = false;
                                        quotesLinia = false;
                                        linia = saveLinia;
                                        paraulaAAjuntar = paraulaAAjuntar.concat("," + word);
                                        AtrString nou = new AtrString(tipusAtributArray.get(i2), paraulaAAjuntar);
                                        tipusAtribut.get(tipusAtributArray.get(i2).getNom()).afegirAtribut(nou);
                                        atributsItem.add(nou);
                                        ++i2;
                                    }
                                    else {
                                        paraulaAAjuntar = paraulaAAjuntar.concat(word);
                                    }
                                }
                                else {
                                    String[] paraula = word.split(";");
                                    ArrayList<String> words = new ArrayList<>(Arrays.asList(paraula));
                                    for (String a : words) {
                                        AtrString nou = new AtrString(tipusAtributArray.get(i2), a);
                                        tipusAtribut.get(tipusAtributArray.get(i2).getNom()).afegirAtribut(nou);
                                        atributsItem.add(nou);
                                    }
                                    ++i2;
                                }
                            }
                        }
                    }
                    else if (trobat)
                    {
                        int num = Integer.parseInt(word);
                        ids.add(num);
                    }
                    else ++i2;
                }
            }


            //Creem l'item amb les relacions d'atributs
            if (linia > 0 && !quotesLinia) {
                int id = ids.get(linia-1);
                Item nou = new Item(id, atributsItem);
                items.put(ids.get(linia-1), nou);
            }
            ++linia;
            if (!quotesLinia) i2 = 0;
        }

        /*
        Lectura Usuaris/Valoracions
         */
        //Get Maxim Rating
        ArrayList<ArrayList<String>> cap = llegeixItems(pathU);
        Iterator<ArrayList<String>> iteratorLinies = cap.listIterator();
        int linea = 0;
        Map<Integer, String> mapCap = new HashMap<>();
        double ratingMax = 0;
        while (iteratorLinies.hasNext())
        {
            Iterator<String> innerIterator = iteratorLinies.next().listIterator();
            double rating;
            int columna = 0;
            while (innerIterator.hasNext())
            {
                String word = innerIterator.next();
                if (linea == 0)
                {
                    mapCap.put(columna, word);
                }
                else
                {
                    if (mapCap.get(columna).equals("rating"))
                    {
                        rating = Double.parseDouble(word);
                        if (rating > ratingMax) ratingMax = rating;
                    }
                }
                ++columna;
            }
            ++linea;
        }
        //Registrar Usuaris/Valoracions
        ArrayList<ArrayList<String>> cap2 = llegeixItems(pathU);
        Iterator<ArrayList<String>> iteratorLinies2 = cap2.listIterator();
        int linea2 = 0;
        while (iteratorLinies2.hasNext())
        {
            Iterator<String> columnesI = iteratorLinies2.next().listIterator();
            int idUsuari = 0;
            int idItem = 0;
            double rating = 0;
            int columna = 0;
            while (columnesI.hasNext())
            {
                String word = columnesI.next();
                if (linea2 != 0)
                {
                    if (mapCap.get(columna).equals("userId")) idUsuari = Integer.parseInt(word);
                    else if (mapCap.get(columna).equals("itemId")) idItem = Integer.parseInt((word));
                    else rating = Double.parseDouble(word);
                }
                ++columna;
            }
            //Afegim Usuari amb l'associació amb Valoració
            if (linea2 > 0)
            {
                if (!usuaris.containsKey(idUsuari)) usuaris.put(idUsuari, new Usuari(idUsuari));
                rating = (rating*5)/ratingMax;
                Valoracio nova = new Valoracio(usuaris.get(idUsuari), rating, "", items.get(idItem));
                Pair<Item, Usuari> key = new Pair<>(items.get(idItem), usuaris.get(idUsuari));
                valoracions.put(key, nova);
                usuaris.get(idUsuari).addItemValoracio(nova);
            }
            ++linea2;
        }
        ArrayList<ArrayList<String>> matU = llegeixItems(pathUnknown);
        Iterator<ArrayList<String>> iteratorLinies3 = matU.listIterator();
        int lineaX = 0;
        Map<Integer, String> mapUnknown = new HashMap<>();
        while (iteratorLinies3.hasNext())
        {
            Iterator<String> innerIterator = iteratorLinies3.next().listIterator();

            int columna = 0;
            while (innerIterator.hasNext())
            {
                String word = innerIterator.next();
                if (lineaX == 0)
                {
                    mapUnknown.put(columna, word);
                }
                ++columna;
            }
            ++lineaX;
        }
        //Registrar Usuaris/Valoracions
        ArrayList<ArrayList<String>> uk2 = llegeixItems(pathUnknown);
        Iterator<ArrayList<String>> iteratorLinies4 = uk2.listIterator();
        int lineaXX = 0;
        while (iteratorLinies4.hasNext())
        {
            Iterator<String> columnesI = iteratorLinies4.next().listIterator();
            int idUsuari = 0;
            int idItem = 0;
            double rating = 0;
            int columna = 0;
            while (columnesI.hasNext())
            {
                String word = columnesI.next();
                if (lineaXX != 0)
                {
                    if (mapUnknown.get(columna).equals("userId")) idUsuari = Integer.parseInt(word);
                    else if (mapUnknown.get(columna).equals("itemId")) idItem = Integer.parseInt((word));
                    else rating = Double.parseDouble(word);
                }
                ++columna;
            }
            //Afegim Usuari amb l'associació amb Valoració
            if (lineaXX > 0)
            {
                if (!unknown.containsKey(idUsuari)) unknown.put(idUsuari, new HashMap<>());
                rating = (rating*5)/ratingMax;
                unknown.get(idUsuari).put(idItem, rating);
            }
            ++lineaXX;
        }
    }

}