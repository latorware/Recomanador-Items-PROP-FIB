package domini; 

public class Distancia {
    
}